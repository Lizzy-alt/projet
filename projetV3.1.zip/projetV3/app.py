from flask import Flask, render_template, request, redirect, url_for, session
import sqlite3
import pandas as pd
from pathlib import Path
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'votre_clé_secrète_ici'  # Nécessaire pour les sessions

#initialisation de la base de données des utilisateurs dans la base de données ma_base.db
def init_user_db():
    conn = sqlite3.connect("ma_base.db")
    cur = conn.cursor()
    
    # Création de la table utilisateurs si elle n'existe pas
    cur.execute("""
        CREATE TABLE IF NOT EXISTS utilisateurs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            mail TEXT UNIQUE NOT NULL,
            username TEXT NOT NULL,
            password TEXT NOT NULL,
            notes TEXT DEFAULT '',
            nb_requetes INTEGER DEFAULT 0,
            enigme_resolue BOOLEAN DEFAULT 0,
            prenom_mere TEXT DEFAULT '',
            date_naissance TEXT DEFAULT ''
        )
    """)
  
    conn.commit()
    conn.close()
# à décacher si reset de la base de données de jeu avec commande dans terminal: attrib -r game.db

#initialisation de la base de données du jeu dans la base de données game.db pour différentier les données du jeu des données des utilisateurs
'''
def init_game_db():
    conn = sqlite3.connect("game.db")
    cur = conn.cursor()
    
    # Création de la table Carte_Enac
    cur.execute("DROP TABLE IF EXISTS Carte_Enac")
    cur.execute("""
        CREATE TABLE Carte_Enac (
            id_Enac TEXT PRIMARY KEY,
            Nom TEXT NOT NULL,
            Prénom TEXT NOT NULL,
            Couleur_de_cheveux TEXT,
            Genre TEXT
        )
    """)

    # Création de la table Boite_mail
    cur.execute("DROP TABLE IF EXISTS Boite_mail")
    cur.execute("""
        CREATE TABLE Boite_mail (
            Date TEXT,
            Message TEXT,
            PRIMARY KEY (Date, Message)
        )
    """)

    # Création de la table PPL
    cur.execute("DROP TABLE IF EXISTS PPL")
    cur.execute("""
        CREATE TABLE PPL (
            Nom TEXT,
            Prénom TEXT,
            Date_obtention TEXT,
            FOREIGN KEY (Nom, Prénom) REFERENCES Carte_Enac(Nom, Prénom)
        )
    """)

    # Création de la table Personnel_Enac
    cur.execute("DROP TABLE IF EXISTS Personnel_Enac")
    cur.execute("""
        CREATE TABLE Personnel_Enac (
            id_Enac TEXT PRIMARY KEY,
            matiere TEXT,
            Enseignement_aux_APPR TEXT,
            FOREIGN KEY (id_Enac) REFERENCES Carte_Enac(id_Enac)
        )
    """)

    # Création de la table Eleve
    cur.execute("DROP TABLE IF EXISTS Eleve")
    cur.execute("""
        CREATE TABLE Eleve (
            id_Enac TEXT PRIMARY KEY,
            Promotion TEXT,
            FOREIGN KEY (id_Enac) REFERENCES Carte_Enac(id_Enac)
        )
    """)

    # Création de la table Goelia
    cur.execute("DROP TABLE IF EXISTS Goelia")
    cur.execute("""
        CREATE TABLE Goelia (
            id_Enac TEXT PRIMARY KEY,
            Etage TEXT,
            Numero_de_chambre TEXT,
            Surface TEXT,
            Nombre_habitants TEXT,
            FOREIGN KEY (id_Enac) REFERENCES Carte_Enac(id_Enac)
        )
    """)

    # Création de la table Temoignages
    cur.execute("DROP TABLE IF EXISTS Temoignages")
    cur.execute("""
        CREATE TABLE Temoignages (
            id_Enac TEXT NOT NULL,
            temoignage TEXT NOT NULL,
            PRIMARY KEY (id_Enac, temoignage),
            FOREIGN KEY (id_Enac) REFERENCES Carte_Enac(id_Enac)
        )
    """)

    # Création de la table Whatsapp
    cur.execute("DROP TABLE IF EXISTS Whatsapp")
    cur.execute("""
        CREATE TABLE Whatsapp (
            pseudo_organisateur TEXT,
            Nom_evenement TEXT,
            date TEXT,
            Lieu TEXT,
            Ville TEXT,
            PRIMARY KEY (pseudo_organisateur, Nom_evenement)
        )
    """)

    # Création de la table Messages
    cur.execute("DROP TABLE IF EXISTS Messages")
    cur.execute("""
        CREATE TABLE Messages (
            Nom_evenement TEXT,
            pseudo_organisateur TEXT,
            message TEXT,
            date TEXT,
            PRIMARY KEY (pseudo_organisateur, message),
            FOREIGN KEY (Nom_evenement) REFERENCES Whatsapp(Nom_evenement),
            FOREIGN KEY (pseudo_organisateur) REFERENCES Whatsapp(pseudo_organisateur)
        )
    """)

    # Importer les données depuis le fichier Excel pour Carte_Enac
    try:
        excel_path = Path("templates/carteenac.xlsx")
        if excel_path.is_file():
            # Lire le fichier Excel
            df = pd.read_excel(excel_path)
            
            # Convertir les types de données
            df['id_Enac'] = df['id_Enac'].astype(str)
            df['Nom'] = df['Nom'].astype(str)
            df['Prénom'] = df['Prénom'].astype(str)
            df['Couleur_de_cheveux'] = df['Couleur_de_cheveux'].astype(str)
            df['Genre'] = df['Genre'].astype(str)
            
            # Insérer les données
            for index, row in df.iterrows():
                cur.execute(
                    'INSERT INTO Carte_Enac (id_Enac, Nom, Prénom, Couleur_de_cheveux, Genre) VALUES (?, ?, ?, ?, ?)',
                    (str(row['id_Enac']), str(row['Nom']), str(row['Prénom']), 
                     str(row['Couleur_de_cheveux']), str(row['Genre']))
                )
            print(f"✅ {len(df)} lignes importées avec succès dans la table Carte_Enac de game.db!")
    except Exception as e:
        print(f"❌ Erreur lors de l'importation de Carte_Enac: {str(e)}")

    # Importer les données depuis le fichier Excel pour Boite_mail
    try:
        excel_path = Path("templates/Boite_mail.xlsx")
        if excel_path.is_file():
            # Lire le fichier Excel
            df = pd.read_excel(excel_path)
            
            # Convertir les types de données
            df['Date'] = df['Date'].astype(str)
            df['Message'] = df['Message'].astype(str)
            
            # Insérer les données
            for index, row in df.iterrows():
                cur.execute(
                    'INSERT INTO Boite_mail (Date, Message) VALUES (?, ?)',
                    (str(row['Date']), str(row['Message']))
                )
            print(f"✅ {len(df)} lignes importées avec succès dans la table Boite_mail de game.db!")
    except Exception as e:
        print(f"❌ Erreur lors de l'importation de Boite_mail: {str(e)}")

    # Importer les données depuis le fichier Excel pour PPL
    try:
        excel_path = Path("templates/PPL.xlsx")
        if excel_path.is_file():
            # Lire le fichier Excel
            df = pd.read_excel(excel_path)
            
            # Convertir les types de données
            df['Nom'] = df['Nom'].astype(str)
            df['Prénom '] = df['Prénom '].astype(str)  # Espace après Prenom, pas d'accent
            df['Date_obtention'] = df['Date_obtention'].astype(str)  # Avec majuscule et underscore
            
            # Insérer les données
            for index, row in df.iterrows():
                cur.execute(
                    'INSERT INTO PPL (Nom, Prénom, Date_obtention) VALUES (?, ?, ?)',
                    (str(row['Nom']), str(row['Prénom ']), str(row['Date_obtention']))
                )
            print(f"✅ {len(df)} lignes importées avec succès dans la table PPL de game.db!")
    except Exception as e:
        print(f"❌ Erreur lors de l'importation de PPL: {str(e)}")

    # Importer les données depuis le fichier Excel pour Personnel_Enac
    try:
        excel_path = Path("templates/Personnel_Enac.xlsx")
        if excel_path.is_file():
            # Lire le fichier Excel
            df = pd.read_excel(excel_path)
            
            # Convertir les types de données
            df['id_Enac'] = df['id_Enac'].astype(str)
            df['matiere'] = df['matiere'].astype(str)
            df['Enseignement_aux_APPR'] = df['Enseignement_aux_APPR'].astype(str)
            
            # Insérer les données
            for index, row in df.iterrows():
                cur.execute(
                    'INSERT OR IGNORE INTO Personnel_Enac (id_Enac, matiere, Enseignement_aux_APPR) VALUES (?, ?, ?)',
                    (str(row['id_Enac']), str(row['matiere']), str(row['Enseignement_aux_APPR']))
                )
            print(f"✅ {len(df)} lignes importées avec succès dans la table Personnel_Enac de game.db!")
    except Exception as e:
        print(f"❌ Erreur lors de l'importation de Personnel_Enac: {str(e)}")

    # Importer les données depuis le fichier Excel pour Eleve
    try:
        excel_path = Path("templates/Eleve.xlsx")
        if excel_path.is_file():
            # Lire le fichier Excel
            df = pd.read_excel(excel_path)
            
            # Convertir les types de données
            df['id_Enac'] = df['id_Enac'].astype(str)
            df['Promotion'] = df['Promotion'].astype(str)
            
            # Insérer les données
            for index, row in df.iterrows():
                cur.execute(
                    'INSERT INTO Eleve (id_Enac, Promotion) VALUES (?, ?)',
                    (str(row['id_Enac']), str(row['Promotion']))
                )
            print(f"✅ {len(df)} lignes importées avec succès dans la table Eleve de game.db!")
    except Exception as e:
        print(f"❌ Erreur lors de l'importation de Eleve: {str(e)}")

    # Importer les données depuis le fichier Excel pour Goelia
    try:
        excel_path = Path("templates/Goelia.xlsx")
        if excel_path.is_file():
            # Lire le fichier Excel
            df = pd.read_excel(excel_path)
            
            # Convertir les types de données
            df['id_Enac'] = df['id_Enac'].astype(str)
            df['Etage'] = df['Etage'].astype(str)
            df['Numero_de_chambre'] = df['Numero_de_chambre'].astype(str)
            df['Surface'] = df['Surface'].astype(str)
            df['Nombre_habitants'] = df['Nombre_habitants'].astype(str)
            
            # Insérer les données
            for index, row in df.iterrows():
                cur.execute(
                    'INSERT INTO Goelia (id_Enac, Etage, Numero_de_chambre, Surface, Nombre_habitants) VALUES (?, ?, ?, ?, ?)',
                    (str(row['id_Enac']), str(row['Etage']), str(row['Numero_de_chambre']), 
                     str(row['Surface']), str(row['Nombre_habitants']))
                )
            print(f"✅ {len(df)} lignes importées avec succès dans la table Goelia de game.db!")
    except Exception as e:
        print(f"❌ Erreur lors de l'importation de Goelia: {str(e)}")

    # Importer les données depuis le fichier Excel pour Temoignages
    try:
        excel_path = Path("templates/Témoignages.xlsx")
        if excel_path.is_file():
            # Lire le fichier Excel
            df = pd.read_excel(excel_path)
            
            # Convertir les types de données
            df['id_Enac'] = df['id_Enac'].astype(str)
            df['temoignage'] = df['temoignage'].astype(str)
            
            # Insérer les données
            for index, row in df.iterrows():
                cur.execute(
                    'INSERT INTO Temoignages (id_Enac, temoignage) VALUES (?, ?)',
                    (str(row['id_Enac']), str(row['temoignage']))
                )
            print(f"✅ {len(df)} lignes importées avec succès dans la table Temoignages de game.db!")
    except Exception as e:
        print(f"❌ Erreur lors de l'importation de Temoignages: {str(e)}")

    # Importer les données depuis le fichier Excel pour Whatsapp
    try:
        excel_path = Path("templates/Whatsapp.xlsx")
        if excel_path.is_file():
            # Lire le fichier Excel
            df = pd.read_excel(excel_path)
            
            # Convertir les types de données
            df['pseudo_organisateur'] = df['pseudo_organisateur'].astype(str)
            df['Nom_evenement'] = df['Nom_evenement'].astype(str)
            df['date'] = df['date'].astype(str)
            df['Lieu'] = df['Lieu'].astype(str)
            df['Ville'] = df['Ville'].astype(str)
            
            # Insérer les données
            for index, row in df.iterrows():
                cur.execute(
                    'INSERT INTO Whatsapp (pseudo_organisateur, Nom_evenement, date, Lieu, Ville) VALUES (?, ?, ?, ?, ?)',
                    (str(row['pseudo_organisateur']), str(row['Nom_evenement']), str(row['date']), 
                     str(row['Lieu']), str(row['Ville']))
                )
            print(f"✅ {len(df)} lignes importées avec succès dans la table Whatsapp de game.db!")
    except Exception as e:
        print(f"❌ Erreur lors de l'importation de Whatsapp: {str(e)}")

    # Importer les données depuis le fichier Excel pour Messages
    try:
        excel_path = Path("templates/Messages.xlsx")
        if excel_path.is_file():
            # Lire le fichier Excel
            df = pd.read_excel(excel_path)
            
            # Convertir les types de données
            df['Nom_evenement'] = df['Nom_evenement'].astype(str)
            df['pseudo_organisateur'] = df['pseudo_organisateur'].astype(str)
            df['message'] = df['message'].astype(str)
            df['date'] = df['date'].astype(str)
            
            # Insérer les données
            for index, row in df.iterrows():
                cur.execute(
                    'INSERT INTO Messages (Nom_evenement, pseudo_organisateur, message, date) VALUES (?, ?, ?, ?)',
                    (str(row['Nom_evenement']), str(row['pseudo_organisateur']), str(row['message']), str(row['date']))
                )
            print(f"✅ {len(df)} lignes importées avec succès dans la table Messages de game.db!")
    except Exception as e:
        print(f"❌ Erreur lors de l'importation de Messages: {str(e)}")
    
    conn.commit()
    conn.close()
 '''
 # à retirer si reset de la base de données du jeu


@app.route("/") #page d'accueil
def index():
    return render_template("index.html")

@app.route("/query", methods=["GET", "POST"]) #page de jeu sql 
def query():
    if 'username' not in session:
        return redirect(url_for('login'))
        
    requete = ""
    erreur = ""
    lignes = []
    colonnes = []
    notes = ""

    # Charger les notes et le compteur de requêtes de l'utilisateur depuis la base de données
    conn_user = sqlite3.connect("ma_base.db")
    cur_user = conn_user.cursor()
    cur_user.execute("SELECT notes, nb_requetes, enigme_resolue FROM utilisateurs WHERE mail = ?", (session['mail'],))
    user_data = cur_user.fetchone()
    nb_requetes = 0
    if user_data:
        notes = user_data[0] or ""
        nb_requetes = user_data[1] or 0
        enigme_resolue = user_data[2] or 0
    conn_user.close()

    # Récupérer et effacer le message de résultat du coupable (pour l'afficher une seule fois)
    culprit_result = session.pop('culprit_result', None)

    if request.method == "POST" and "sql" in request.form:
        
        # Récupérer les notes du formulaire et les sauvegarder
        notes = request.form.get("notes", "")
        
        # Incrémenter le compteur de requêtes et sauvegarder les notes seulement si l'énigme n'est pas résolue
        conn_user = sqlite3.connect("ma_base.db")
        cur_user = conn_user.cursor()
        if enigme_resolue != 2:  # Si l'énigme n'est pas résolue
            cur_user.execute("UPDATE utilisateurs SET notes = ?, nb_requetes = nb_requetes + 1 WHERE mail = ?", (notes, session['mail']))
        else:  # Si l'énigme est résolue, on met juste à jour les notes
            cur_user.execute("UPDATE utilisateurs SET notes = ? WHERE mail = ?", (notes, session['mail']))
        conn_user.commit()
        
        # Récupérer le compteur actuel
        cur_user.execute("SELECT nb_requetes FROM utilisateurs WHERE mail = ?", (session['mail'],))
        result = cur_user.fetchone()
        if result:
            nb_requetes = result[0]
        conn_user.close()
        
        requete = request.form["sql"]
        try:
            conn = sqlite3.connect("game.db")  # Utilisation de la base de données du jeu
            cur = conn.cursor()

            cur.execute(requete)
            if requete.strip().lower().startswith("select"):
                lignes = cur.fetchall()
                colonnes = [desc[0] for desc in cur.description]
            else:
                erreur = "Veuillez saisir une requête."

        except sqlite3.Error as erreur_sql:
            erreur = f"Erreur SQL : {erreur_sql}"
        
    return render_template("query.html", requete=requete, colonnes=colonnes, lignes=lignes, erreur=erreur, notes=notes, nb_requetes=nb_requetes, culprit_result=culprit_result)


@app.route("/login", methods=["GET", "POST"]) #route de la page de connexionm -GET sert à afficher le formulaire-POST sert à traiter les données envoyées par l'utilisateur.
def login():
    error = None
    if request.method == "POST":
        mail = request.form['mail']           # Récupère l'email saisi dans le formulaire
        password = request.form['password']   # Récupère le mot de passe saisi

        # Connexion à la base de données des utilisateurs
        conn = sqlite3.connect("ma_base.db")
        cur = conn.cursor()
        cur.execute("SELECT * FROM utilisateurs WHERE mail = ?", (mail,))
        user = cur.fetchone()                 # Récupère la ligne utilisateur correspondant à l'email
        conn.close()

        # Vérifie si l'utilisateur existe et si le mot de passe est correct
        if user and check_password_hash(user[3], password):  # user[3] = mot de passe haché
            session['username'] = user[2]    # Stocke le username dans la session (user[2])
            session['mail'] = user[1]        # Stocke l'email dans la session (user[1])
            return redirect(url_for('query')) # Redirige vers la page de jeu SQL
        else:
            error = "Email ou mot de passe incorrect"  # Message d'erreur si mauvais identifiants

    # Affiche la page de connexion, avec un éventuel message d'erreur
    return render_template("login.html", error=error)

@app.route("/signup", methods=["GET", "POST"]) #route de la page d'inscription
def signup():
    error = None
    if request.method == "POST":
        mail = request.form['mail']
        username = request.form['username']
        password = request.form['password']
        prenom_mere = request.form['prenom_mere'].strip().lower()
        date_naissance = request.form['date_naissance']
        
        # Hacher le mot de passe
        hashed_password = generate_password_hash(password)
        
        conn = sqlite3.connect("ma_base.db")  # Base de données des utilisateurs
        cur = conn.cursor()
        
        try: #essaye d'insérer les données dans la base de données
            cur.execute("""INSERT INTO utilisateurs 
                           (mail, username, password, prenom_mere, date_naissance) 
                           VALUES (?, ?, ?, ?, ?)""", 
                       (mail, username, hashed_password, prenom_mere, date_naissance))
            conn.commit()
            conn.close()
            return redirect(url_for('login'))
        except sqlite3.IntegrityError: #si l'email est déjà utilisé, affiche un message d'erreur
            error = "Cet email est déjà utilisé"
            conn.close()
    
    return render_template("signup.html", error=error) 

@app.route("/logout") #route de la page de déconnexion
def logout():
    session.pop('username', None)
    return redirect(url_for('index'))

@app.route("/forgot_password", methods=["GET", "POST"])
def forgot_password():
    if request.method == "POST":
        mail = request.form['mail']
        new_password = request.form['new_password']
        confirm_password = request.form['confirm_password']
        prenom_mere = request.form['prenom_mere'].strip().lower()
        date_naissance = request.form['date_naissance']
        
        # Vérifier que les mots de passe correspondent
        if new_password != confirm_password:
            return render_template("forgot_password.html", error="Les mots de passe ne correspondent pas")
        
        # Vérifier que l'email existe et récupérer les réponses de sécurité
        conn = sqlite3.connect("ma_base.db")
        cur = conn.cursor()
        cur.execute("SELECT prenom_mere, date_naissance FROM utilisateurs WHERE mail = ?", (mail,))
        user = cur.fetchone()
        
        if not user:
            conn.close()
            return render_template("forgot_password.html", error="Aucun compte trouvé avec cet email")
        
        # Vérifier les réponses aux questions de sécurité
        if user[0] != prenom_mere or user[1] != date_naissance:
            conn.close()
            return render_template("forgot_password.html", error="Les réponses aux questions de sécurité sont incorrectes")
        
        # Hacher le nouveau mot de passe et le mettre à jour
        hashed_password = generate_password_hash(new_password)
        try:
            cur.execute("UPDATE utilisateurs SET password = ? WHERE mail = ?", (hashed_password, mail))
            conn.commit()
            conn.close()
            return render_template("forgot_password.html", success="Votre mot de passe a été modifié avec succès. Vous pouvez maintenant vous connecter.")
        except Exception as e:
            conn.close()
            return render_template("forgot_password.html", error="Une erreur s'est produite lors de la modification du mot de passe")
    
    return render_template("forgot_password.html")

@app.route("/leaderboard")
def leaderboard():
    if 'username' not in session:
        return redirect(url_for('login'))
    
    # Récupérer tous les utilisateurs avec leur statut d'énigme et nombre de requêtes
    # Trier d'abord par énigme résolue (DESC), puis par nombre de requêtes (ASC), puis par nom (ASC)
    conn = sqlite3.connect("ma_base.db")
    cur = conn.cursor()
    cur.execute("""
        SELECT username, nb_requetes, enigme_resolue 
        FROM utilisateurs 
        ORDER BY enigme_resolue DESC, nb_requetes ASC, username ASC
    """)
    users_data = cur.fetchall()
    conn.close()
    
    # Créer le classement avec rang
    leaderboard_data = []
    for i, (username, nb_requetes, enigme_resolue) in enumerate(users_data):
        leaderboard_data.append({
            'rang': i + 1,
            'username': username,
            'nb_requetes': nb_requetes or 0,
            'enigme_resolue': enigme_resolue == 2,  # Seul enigme_resolue = 2 signifie enquête terminée
            'is_current_user': username == session['username']
        })
    
    return render_template("leaderboard.html", leaderboard=leaderboard_data)

@app.route("/settings")
def settings():
    if 'username' not in session:
        return redirect(url_for('login'))
    return render_template("settings.html")

@app.route("/update_account", methods=["POST"])
def update_account():
    if 'username' not in session:
        return redirect(url_for('login'))
    
    mail = request.form['mail']
    username = request.form['username']
    new_password = request.form['new_password']
    current_password = request.form['current_password']
    
    conn = sqlite3.connect("ma_base.db")  # Base de données des utilisateurs
    cur = conn.cursor()
    
    # Vérifier le mot de passe actuel
    cur.execute("SELECT * FROM utilisateurs WHERE mail = ?", (session['mail'],))
    user = cur.fetchone()
    
    if not user or not check_password_hash(user[3], current_password):  # user[3] est le mot de passe haché
        conn.close()
        return render_template("settings.html", error="Mot de passe actuel incorrect")
    
    try:
        if new_password:
            # Si un nouveau mot de passe est fourni, le hacher et le mettre à jour aussi
            hashed_password = generate_password_hash(new_password)
            cur.execute("""
                UPDATE utilisateurs 
                SET mail = ?, username = ?, password = ?
                WHERE mail = ?
            """, (mail, username, hashed_password, session['mail']))
        else:
            # Sinon, mettre à jour uniquement mail et username
            cur.execute("""
                UPDATE utilisateurs 
                SET mail = ?, username = ?
                WHERE mail = ?
            """, (mail, username, session['mail']))
        
        conn.commit()
        
        # Mettre à jour la session
        session['mail'] = mail
        session['username'] = username
        
        conn.close()
        return render_template("settings.html", success="Modifications enregistrées avec succès")
    
    except sqlite3.IntegrityError:
        conn.close()
        return render_template("settings.html", error="Cet email est déjà utilisé")

@app.route("/delete_account", methods=["POST"])
def delete_account():
    if 'username' not in session:
        return redirect(url_for('login'))
    
    password = request.form['password']
    
    conn = sqlite3.connect("ma_base.db")  # Base de données des utilisateurs
    cur = conn.cursor()
    
    # Vérifier le mot de passe
    cur.execute("SELECT * FROM utilisateurs WHERE mail = ?", (session['mail'],))
    user = cur.fetchone()
    
    if not user or not check_password_hash(user[3], password):  # user[3] est le mot de passe haché
        conn.close()
        return render_template("settings.html", error="Mot de passe incorrect")
    
    # Supprimer le compte
    cur.execute("DELETE FROM utilisateurs WHERE mail = ?", (session['mail'],))
    conn.commit()
    conn.close()
    
    # Déconnecter l'utilisateur
    session.clear()
    return redirect(url_for('index'))

@app.route("/check_culprit", methods=["POST"])
def check_culprit():
    # Vérifie si l'utilisateur est connecté, sinon redirige vers la page de connexion
    if 'username' not in session:
        return redirect(url_for('login'))
    
    # Récupère le nom du coupable saisi par l'utilisateur et supprime les espaces au début et à la fin
    culprit_name = request.form['culprit_name'].strip()
    
    # Connexion à la base de données des utilisateurs
    conn = sqlite3.connect("ma_base.db")
    cur = conn.cursor()
    
    # Récupère l'étape actuelle de l'utilisateur (0, 1 ou 2) depuis la base de données
    cur.execute("SELECT enigme_resolue FROM utilisateurs WHERE mail = ?", (session['mail'],))
    user_data = cur.fetchone()
    enigme_resolue = user_data[0] if user_data else 0
    
    # Liste des réponses possibles pour le premier coupable (Maxime Keller)
    first_culprit_answers = ["maxime keller", "Maxime Keller", "MAXIME KELLER", "Maxime keller", "maxime Keller"]
    
    # Liste des réponses possibles pour le deuxième coupable (Magalie Capelle)
    final_culprit_answers = ["magalie capelle", "Magalie Capelle", "MAGALIE CAPELLE", "Magalie capelle", "magalie Capelle"]
    
    # Vérifie si c'est le premier coupable et si l'utilisateur est à l'étape 0
    if enigme_resolue == 0 and culprit_name in first_culprit_answers:
        # Stocke le message de succès dans la session pour l'afficher une seule fois
        session['culprit_result'] = 'first_success'
        
        # Met à jour la base de données pour indiquer que le premier coupable a été trouvé (étape 1)
        cur.execute("UPDATE utilisateurs SET enigme_resolue = 1 WHERE mail = ?", (session['mail'],))
        conn.commit()
        
    # Vérifie si c'est le deuxième coupable et si l'utilisateur est à l'étape 1
    elif enigme_resolue == 1 and culprit_name in final_culprit_answers:
        # Stocke le message de succès final dans la session pour l'afficher une seule fois
        session['culprit_result'] = 'final_success'
        
        # Met à jour la base de données pour indiquer que l'énigme est complètement résolue (étape 2)
        cur.execute("UPDATE utilisateurs SET enigme_resolue = 2 WHERE mail = ?", (session['mail'],))
        conn.commit()
        
    else:
        # Si la réponse est incorrecte, stocke un message d'erreur dans la session
        session['culprit_result'] = 'error'
    
    # Ferme la connexion à la base de données
    conn.close()
    
    # Redirige l'utilisateur vers la page de requêtes SQL
    return redirect(url_for('query'))

@app.route("/conditions")
def conditions():
    return render_template("conditions.html")

if __name__ == "__main__":
    init_user_db()  # Initialiser la base de données des utilisateurs
    #init_game_db()  # Initialiser la base de données du jeu, à décacher si reset de la base de données du jeu
    app.run(debug=True)
